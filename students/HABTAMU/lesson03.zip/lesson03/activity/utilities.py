def printu(message):
    print(f'---\n\n{message}')
    print('=' * len(message))
