# Terrible program
Can you make is run?
Can you decipher what it is tryng to do?